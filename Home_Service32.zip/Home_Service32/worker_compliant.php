<?php
include "header.php";
?>
<style>
body{
	margin: 0;
	padding: 0; 
	background-size: cover;
	background-position: center;
	font-family: sans-serif;
	background-color:gainsboro;
	}
</style>

<div class="panel panel-primary" style="max-width:300px;margin:auto">
		<div class="panel-heading">
			COMPLAINT
		</div>

		<div class="panel-body panel-center">
		
<?php
include "dbi.php";

$query="select * from feedback";

$result = mysqli_query($con,$query);

while($row=mysqli_fetch_array($result))
{
	$name=$row["name"];
	$e_mail=$row["e_mail"];
	$u_date=date("Y-m-d");
	$comments=$row["comments"];
}


?>

<form class="form" action="act_feedback.php" method="post">		


<div class="form-group">
<label for="nameField">Name</label>
<input type="text" class="form-control input-sm" value="<?php echo $name;?>" name="name" placeholder="Enter Your Name" />
</div>

<div class="form-group">
<label for="nameField">E-mail</label>
<input type="text" class="form-control input-sm" value="<?php echo $e_mail;?>" name="e_mail" placeholder="Enter your Email Id" />
</div>

<div class="form-group">
<label for="nameField">Date</label>
<input type="text" class="form-control input-sm" value="<?php echo $u_date;?>" name="u_date" placeholder="Date" />
</div>


<div class="form-group">
<label for="nameField">Comments</label>
<textarea class="form-control input-sm" row="4" cols="50" value="<?php echo $comments;?>" name="comments" placeholder="Enter Your Comments Here"></textarea>
</div>

<input type="submit" class="btn btn-success btn-block" value="Submit" />
</form>
		</div>

		<div class="panel-footer text-center">
			
<a href="index.php">Back To Panel</a>
		</div>

	</div>


<?php
include "footer.php";
?>




