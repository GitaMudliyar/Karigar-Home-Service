<?php
include "header.php";   // require "header.php";
include "dbi.php";
$skill=$_GET["sk"];

$query = "select * from worker_profile where w_uname in (select w_uname from v_skills where service_type='$skill')";

$skill=strtoupper($skill);
$result=mysqli_query($con,$query);
echo "<h2 class='text-center'>$skill</h2>";
echo '<div class="table-responsive">';
echo '<table class="table table-hover table-bordered table-striped">';
echo "<tr><th>No</th><th>Name</th><th>City</th></tr>";

$cnt=0;

while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$nm = $row["fname"]." ".$row["lname"];

	echo "<tr>";
	echo "<td>".$cnt."</td>";
	echo "<td>".$nm."</td>";
	echo "<td>".$row["location"]."</td>";

	echo "</tr>";
	
}


echo "</table></div>";
echo "<p><center><a href='index.php'> Back </a></center></p>";
 ?>


 
 <?php
include "footer.php";   // require "header.php";
 ?>