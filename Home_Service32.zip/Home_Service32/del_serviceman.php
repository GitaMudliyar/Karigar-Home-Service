<?php
include "header.php";
$w_uname= $_GET["w_uname"];

require "dbi.php";
$query="select * from worker_profile where w_uname=w_uname";

?>
<html>
<body>
<center>
<p><a href='view_serviceman.php'>Back to List</a></p>

<form action="delete_serviceman.php" method="post">

<?php
	echo "<h2 style='color:red'>Delete Worker: $w_uname</h2>";
	echo "<h2>Are You Sure?</h2>";

?>

<input type="hidden" name="w_uname" value="<?php echo $w_uname; ?>" />


<input type="submit"  value="Confirm Delete"/>

</form>
</center>
</body>
</html>