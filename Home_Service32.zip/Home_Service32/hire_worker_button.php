<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">

<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link href="css/styles.css" rel="stylesheet">
</head>
<body>
<div class="container">

<div class="modal fade" id="myModal">
<div class="modal-dialog">
<div class="modal-content">
	<!-- Modal Header -->
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			<h4 class="modal-title">Confirm task!</h4>
		</div>

	<!-- Modal Body -->
<div class="modal-body">
	<h1>Ready to hire worker!</h1>
</div>

	<!-- Modal Footer -->
	<div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		<button type="button" class="btn btn-primary">confirm</button>
	</div>
</div>
</div>
</div>

<button class="btn btn-primary btn-lg" data-toggle="modal"data-target="#myModal">
	Hire1
</button>
</div>

<script src="js/jquery.js"></script>
<script src="js/bootstrap.js"></script>

<script type="text/javascript">
	$(document).ready(function(){
		var options = {
				backdrop: true,
				keyboard: false,
				show: true,
				remote: false
			     }

$("#myModal").modal(options);

	});
</script>
</body>
</html>