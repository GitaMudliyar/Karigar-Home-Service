<?php
include "header.php";

require "validate_member.php";
?>
<style>
body{
	margin: 0;
	padding: 0;
	background : url(pic1.jpg); 
	background-size: cover;
	background-position: center;
	font-family: sans-serif;
	background-color:gainsboro;
}
</style>

<div class="panel panel-primary" style="max-width:300px;margin:auto">
		<div class="panel-heading">
			Member Profile
		</div>

		<div class="panel-body panel-center">
	



<?php
include "dbi.php";

if(!empty($uname))
{
	$result = mysqli_query($con,"select * from member_profile where m_uname='$uname'");

	if($row=mysqli_fetch_array($result))
	{		
$fname=$row["fname"];
$lname=$row["lname"];
$area=$row["area"];
$location=$row["location"];
$contact=$row["contact"];
$udt=date("Y-m-d");

	}
	else
	{
		$fname="";$lname="";$area="";$location="";$contact=""; $udt="";
	}

}


?>

<form class="form" action="update_mprofile.php" method="post">
<div class="form-group">
<label for="nameField">First Name</label>
<input type="text" class="form-control input-sm" required value = "<?php echo $fname; ?>" name="fname" placeholder="First Name" />
</div>

<div class="form-group">
<label for="nameField">Last Name</label>
<input type="text" class="form-control input-sm" required value="<?php echo $lname; ?>" name="lname" placeholder="Last Name" />
</div>

<div class="form-group">
<label for="nameField">Area</label>
<input type="text" class="form-control input-sm" required value="<?php echo $area; ?>" name="area" placeholder="Street,Area" />
</div>

<div class="form-group">
<label for="nameField">City</label>
<input type="text" class="form-control input-sm" required value="<?php echo $location; ?>" name="location" placeholder="City" />
</div>



<div class="form-group">
<label for="nameField">Contact</label>
<input type="text" class="form-control input-sm" value="<?php echo $contact;?>" name="contact" placeholder="Address" />
</div>

<div class="form-group">
<label for="nameField">Updated on</label>
<input type="text" readonly class="form-control input-sm" value="<?php echo $udt; ?>" name="udate"  placeholder="Updated Date" />
</div>


<input type="submit" class="btn btn-warning btn-block" value="Update Profile" /> 
</form>
		</div>

		<div class="panel-footer text-center">
			
<a href="member.php">Back To Panel</a>
		</div>

	</div>


<?php
include "footer.php";
?>




