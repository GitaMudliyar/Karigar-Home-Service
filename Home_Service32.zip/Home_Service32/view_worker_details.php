<?php
include "header.php";
?>
<style>
body{
	margin: 0;
	padding: 0;
	background : url(pic1.jpg); 
	background-size: cover;
	background-position: center;
	font-family: sans-serif;
}
td{
	color:Navy;
}
</style>
<?php
include "dbi.php";
$w_uname = $_GET["w_uname"];
$sid = $_GET["sid"];
$sk = $_GET["sk"];

echo "<p><center><a href='view_serviceman.php?sid=$sid&sk=$sk'>Back</a></center></p>";
if(!empty($w_uname))
{
	$result = mysqli_query($con,"select * from worker_profile where w_uname='$w_uname'");

	if($row=mysqli_fetch_array($result))
	{
	$nm = $row["fname"]." ".$row["lname"];	
//$fn=$row["fname"];
//$ln=$row["lname"];
$age=$row["age"];
$gender=$row["gender"];
$qual=$row["qualification"];
//$work=$row["work"];
$area=$row["area"];
$location=$row["location"];
$contact=$row["contact"];
$udt=date("Y-m-d");
	}
	else
	{
		$fn=""; $ln=""; $age=""; $gender=""; $qual="";$area=""; $location=""; $contact=""; $udt="";
	}

}

echo "<h2 class='text-center' style='color:DeepPink;'>User Name:- $w_uname Details</h2>";
echo '<div class="table-responsive">';
echo '<table class="table table-hover table-bordered table-striped">';
echo "<tr><td>Name</td><td>$nm</td></tr>";

	echo "<tr><td>Profile Picture</td><td>";
	//echo "<a href='file_upload.php?w_uname=$w_uname'>";
	echo "<img src='profile_pics/pic$w_uname.png' width='60px' height='60px'/></a>";
	echo "</td></tr>";


echo "<tr><td>Age</td><td>$age</td></tr>";
echo "<tr><td>Gender</td><td>$gender</td></tr>";
echo "<tr><td>Qualification</td><td>$qual</td></tr>";
echo "<tr><td>Area</td><td>$area</td></tr>";
echo "<tr><td>Location</td><td>$location</td></tr>";
echo "<tr><td>Contact</td><td>$contact</td></tr>";
echo "<tr><td>Updated Profile on</td><td>$udt</td></tr>";
echo "<tr></tr>";

echo "</table>";
mysqli_close($con);
//echo "<a href='view_serviceman.php'>Back</a>";
?>
<?php
include "footer.php";
?>




