<?php
include "header.php";

require "validate_member.php";
?>


<h1>Welcome Member</h1>
  <div class="list-group">
	<a href="member_profile.php" class="list-group-item">Update My Profile</a>
	<a href="member_service_list.php" class="list-group-item">Karigar Services</a>
	<a href="m_view_complaints.php" class="list-group-item">My Complaint(s)</a>
	<a href="m_view_complaint_history.php" class="list-group-item">Complaint History</a>
	<a href="m_send_admin.php" class="list-group-item">Message to Admin</a>
	<a href="m_received_messages.php" class="list-group-item">Inbox</a>
	<a href="m_sent_messages.php" class="list-group-item">Outbox</a>
	
  </div>


<?php
include "footer.php";
?>




