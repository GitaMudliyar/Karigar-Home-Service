<?php
require "dbi.php";


$f_uname=$_POST["uname"];
//$from=$_POST["uname"];
$t_uname=$_POST["w_uname"];
$to=$_POST["nm"];
$mdate=$_POST["mdate"];
$subject=$_POST["subject"];
$contents=$_POST["contents"];
//$sid=$_POST["sid"];
//$sk=$_POST["sk"];

$query="insert into message(f_uname,from_u,t_uname,to_u,mdate,subject,contents) values('$f_uname','Admin','$t_uname','$to','$mdate','$subject','$contents')";


mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	header("location:view_all_workers.php");
}

?>