<?php
require "dbi.php";

$service_type=strtoupper($_POST["service_type"]);

$query="insert into service_master(service_type) values('$service_type')";

mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	header("location:service_list.php");
}

?>