<?php
include "header.php";

require "validate_admin.php";
?>


<h1>Welcome Administrator</h1>
  <div class="list-group">
	<a href="service_list.php" class="list-group-item">Our Services</a>
	<a href="view_all_members.php" class="list-group-item">View Members Profile</a>
	<a href="view_all_workers.php" class="list-group-item">View Workers Profile</a>
	<a href="a_view_complaints.php" class="list-group-item">View Complaint(s)</a>
	<a href="a_view_complaint_history.php" class="list-group-item">Complaint History</a>
	<a href="a_received_messages.php" class="list-group-item">Inbox</a>
	<a href="a_sent_messages.php" class="list-group-item">Outbox</a>
	<a href="feedback_select.php" class="list-group-item">View Feedback</a>
	
  </div>


<?php
include "footer.php";
?>




