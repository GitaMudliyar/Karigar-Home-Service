<?php
include "header.php";
?>
<style>
body{
	margin: 0;
	padding: 0;
	background : url(pic1.jpg); 
	background-size: cover;
	background-position: center;
	font-family: sans-serif;
}
</style>

<div class="panel panel-primary" style="max-width:300px;margin:auto">
		<div class="panel-heading">
			HIRE WORKER
		</div>

		<div class="panel-body panel-center">

	<form class="form" action="hire_worker_button" method="post">		


<div class="form-group">
<label for="nameField">Day for visiting</label>
<select name="v_day">
	<option value="anyday">Any Day</option>
	<option value="sunday">Sunday Only</option>
	<option value="monday">Monday Only</option>
	<option value="tuesday">Tuesday Only</option>
	<option value="wednesday">Wednesday Only</option>
	<option value="thursday">Thursday Only</option>
	<option value="friday">Friday Only</option>
	<option value="saturday">Saturday Only</option>

<div class="form-group">
<label for="nameField">Comments</label>
<input type="textarea" class="form-control input-sm" name="" required placeholder="Some information about work or schedule" />
</div>



</div>
<div class="form-group">
<label for="nameField">Updated on</label>
<input type="text" readonly class="form-control input-sm" name="udate" required placeholder="Updated Date" />
</div>


<input type="submit" class="btn btn-warning btn-block" value="Hire" />


</form>
		</div>

		<div class="panel-footer text-center">
			
<a href="carpenter.php">Back To Panel</a>
		</div>

	</div>


<?php
include "footer.php";
?>




