<?php
include "header.php";

//include "validate_worker.php";
?>
<style>
body{
	margin: 0;
	padding: 0;
	background : url(pic1.jpg); 
	background-size: cover;
	background-position: center;
	font-family: sans-serif;
}
</style>

<div class="panel panel-primary" style="max-width:300px;margin:auto">
		<div class="panel-heading">
			SEND MESSAGE
		</div>

		<div class="panel-body panel-center">
		<?php
include "dbi.php";
//$from_u=$_GET["w_uname"];
//$sid=$_GET["sid"];
///$nm=$_GET["nm"];
//$sk=$_GET["sk"];
$udt=date('Y-m-d');
///$t_uname=$_GET["w_nm"];




$query = "select * from member_profile where m_uname='$uname'";
$result = mysqli_query($con,$query) or die(mysqli_error($con));

while($row=mysqli_fetch_array($result))
{
	$m_nm = $row["fname"]." ".$row["lname"];
	
}

?>

<form class="form" action="insert_message_m_to_admin.php" method="post">		

<div class="form-group">
<label for="nameField">Date</label>
<input type="text" readonly class="form-control input-sm" name="mdate" value="<?php echo $udt;?>" />
</div>

<input type="hidden"  value="<?php echo $m_nm;?>" name="m_nm"/>
<input type="hidden"  value="<?php echo $uname;?>" name="uname"/>


<div class="form-group">
<label for="nameField">To</label>
<input type="text" class="form-control input-sm" readonly value="<?php echo 'Karigar Admin';?>" placeholder="Worker Name" />
</div>

<!--<input type="hidden" class="form-control input-sm" name="sid" />-->

<div class="form-group">
<label for="nameField">Subject</label>
<input type="text" class="form-control input-sm" name="subject" placeholder="Subject" />
</div>

<div class="form-group">
<label for="nameField">Contents</label>
<textarea class="form-control input-sm" rows="4" cols="50"  name="contents" placeholder="Body of Message"></textarea>
</div>


<input type="submit" class="btn btn-success btn-block" value="Send" /> 
</form>
		</div>

		<div class="panel-footer text-center">
<?php			
echo "<a href='member.php'>Back To Panel</a>";
?>
		</div>

	</div>


<?php
include "footer.php";
?>