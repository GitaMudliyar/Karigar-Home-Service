<?php
include "header.php";

require "validate_worker.php";
?>


<h1>Welcome Worker</h1>
  <div class="list-group">
	<a href="worker_profile.php" class="list-group-item">Update My Profile</a>
	<a href="worker_work_details.php" class="list-group-item">My Work Details</a>
	<a href="w_view_complaints.php" class="list-group-item">View New Complaint(s)</a>
	<a href="w_view_complaint_history.php" class="list-group-item">Complaint History</a>
	<a href="w_send_admin.php" class="list-group-item">Message to Admin</a>
	<a href="w_received_messages.php" class="list-group-item">Inbox</a>
	<a href="w_sent_messages.php" class="list-group-item">Outbox</a>
	
  </div>


<?php
include "footer.php";
?>




