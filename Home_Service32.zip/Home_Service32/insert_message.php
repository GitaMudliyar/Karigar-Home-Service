<?php
require "dbi.php";


$from=$_POST["uname"];
$to=$_POST["w_uname"];
$mdate=$_POST["mdate"];
$subject=$_POST["subject"];
$contents=$_POST["contents"];
$sid=$_POST["sid"];
$sk=$_POST["sk"];

$query="insert into message(from_u,to_u,mdate,subject,contents) values('$from','$to','$mdate','$subject','$contents')";

mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	header("location:view_serviceman.php?sid=$sid&sk=$sk");
}

?>