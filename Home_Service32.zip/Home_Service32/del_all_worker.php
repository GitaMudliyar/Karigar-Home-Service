<?php
include "header.php";
$w_uname= $_GET["w_uname"];
$nm=$_GET["nm"];

require "dbi.php";


$query="select * from worker_profile where w_uname='$w_uname'";

$result=mysqli_query($con,$query) or die(mysqli_error($con));

if($row=mysqli_fetch_array($result))
{
	$w_uname=$row["w_uname"];
}
else
{
	echo "<center><h2>Worker Not Found</h2>";
	echo "<p><a href='view_all_workers.php'>Back</a></p></center>";
	exit;
}

?>
<html>
<body>
<center>
<p><a href='view_all_workers.php'>Back to List</a></p>

<form action="delete_all_worker.php" method="post">

<?php
	echo "<h2 style='color:red'>Remove Worker - $nm</h2>";
	echo "<h2>Are You Sure?</h2>";

?>

<input type="hidden" name="w_uname" value="<?php echo $w_uname; ?>" />


<input type="submit"  value="Confirm Delete"/>

</form>
</center>
</body>
</html>