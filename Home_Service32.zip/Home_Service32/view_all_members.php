<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>
<?php
include "header.php";
require "dbi.php";

$filter = isset($_POST["filter"])?$_POST["filter"]:"";
$btn = isset($_POST["btn"])?$_POST["btn"]:"";

if(empty($filter) || $btn=="Show All")
{
	$query="select * from member_profile";// order by m_uname";
	$filter="";
}
else
{
	$query="select * from member_profile where m_uname like '%$filter%'; //order by m_uname";
}


//$query="select * from member_profile";//order by m_uname

$result = mysqli_query($con,$query) or die(mysqli_error($con));

echo "<center>";

echo "<p><h3>Members</h3></p><br>";

//echo "Search:- <input type='text' name='filter' value='$filter' /> ";
//echo "<input type='submit' value='Filter' name='btn' />";
//echo "<input type='submit' value='Show All' name='btn' /><br><br>";

echo '<div class="table-responsive">';
echo "<table border='1'>";
echo "<tr bgcolor='gold'><th><center>Sr. No.</center></th><th><center>User Name</center></th><th><center>Name</center></th>";
echo "<th><center>Address</center></th><th><center>Contact</center></th><th><center>Action</center></th></tr>";

$cnt=0;

while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$m_uname=$row["m_uname"];
	//$fname=$row["fname"];
	//$lname=$row["lname"];
	$nm = $row["fname"]." ".$row["lname"];
	$area=$row["area"];
	$location=$row["location"];
	$contact=$row["contact"];

	echo "<tr>";
	echo "<td align='center'>$cnt</td>";
	echo "<td>&nbsp;".$row["m_uname"]."</td>";
	//echo "<td>&nbsp;".$row["fname"];
	//echo "&nbsp;".$row["lname"]."</td>";
	
	echo "<td>&nbsp;".$nm."</td>";
	echo "<td>&nbsp;".$row["area"];
	echo ",&nbsp;".$row["location"]."</td>";
	echo "<td>&nbsp;".$row["contact"]."</td>";
	
	echo "<td>";
	echo "&nbsp;<a href='send_message_to_member.php? m_uname=$m_uname&nm=$nm'>Send Message</a>";
	echo "&nbsp;<a href='del_member.php?m_uname=$m_uname&nm=$nm'>&nbsp;&nbsp;&nbsp;&nbsp;Remove</a></td>";
	
	echo "</tr>";
}

echo "</table></div>";

echo "<br><p><a href='admin.php'>Back to Panel</a></p>";

echo "<center>";

mysqli_close($con);
?>