<?php
require "dbi.php";



$from=$_POST["w_nm"];
//$to=$_POST["nm"];
$f_uname=$_POST["uname"];
//$t_uname=$_POST["t_uname"];
$mdate=$_POST["mdate"];
$subject=$_POST["subject"];
$contents=$_POST["contents"];
//$sid=$_POST["sid"];
//$sk=$_POST["sk"];

echo "$to";
$query="insert into message(f_uname,from_u,t_uname,to_u,mdate,subject,contents) values('$f_uname','$from','ad','Admin','$mdate','$subject','$contents')";
echo "$query";
mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_affected_rows($con) > 0)
{
	header("location:worker.php");
}

?>