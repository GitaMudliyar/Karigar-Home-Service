<?php
include "carouse.php";   // require "header.php";
include "header.php";
 ?>
   <div class="row">
	<div class="col-xs-3">
		<a href="service_providers.php?sk=carpenter" class="thumbnail">
		<img src="./images/carpenter.png">
		</a>
	</div>
	<div class="col-xs-3">
		<a href="service_providers.php?sk=electrician" class="thumbnail">
		<img src="./images/electrician.png">
		</a>
	</div>
	<div class="col-xs-3">
		<a href="service_providers.php?sk=painter" class="thumbnail">
		<img src="./images/painter.png">
		</a>
	</div>
	<div class="col-xs-3">
		<a href="service_providers.php?sk=interior DECORATOR" class="thumbnail">
		<img src="./images/interior.png">
		</a>
	</div>
  </div>

  <div class="row">
	<div class="col-xs-3">
		<a href="service_providers.php?sk=pool cleaner" class="thumbnail">
		<img src="./images/pool_cleaner.png">
		</a>
	</div>
	<div class="col-xs-3">
		<a href="service_providers.php?sk=plumber" class="thumbnail">
		<img src="./images/plumber.png">
		</a>
	</div>
	<div class="col-xs-3">
		<a href="service_providers.php?sk=TREE SHAPER" class="thumbnail">
		<img src="./images/tree_shaper.png">
		</a>
	</div>
	<div class="col-xs-3">
		<a href="service_providers.php?sk=tiles fixer" class="thumbnail">
		<img src="./images/tiles_fixer.png">
		</a>
	</div>
  </div>
  <?php
include "footer.php";   // require "header.php";
 ?>