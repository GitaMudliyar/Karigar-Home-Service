<?php
$w_uname=$_POST["w_uname"];
$st= $_POST["service_type"];

require "dbi.php";

$query="delete from service_provider where sid=(select sid from service_master where service_type='$st') and w_uname='$w_uname'";

mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	header("location:worker.php");
}

?>