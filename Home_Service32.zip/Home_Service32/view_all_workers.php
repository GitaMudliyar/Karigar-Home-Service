<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>
<?php
include "header.php";
require "dbi.php";

$query="select * from worker_profile";//order by m_uname

$result = mysqli_query($con,$query) or die(mysqli_error($con));

echo "<center>";

echo "<p><h3>Workers</h3></p>";

echo '<div class="table-responsive">';
echo "<table border='1'>";
echo "<tr bgcolor='gold'><th><center>Sr. No.</center></th><th><center>User Name</center></th><th><center>Name</center></th>";
echo "<th><center>Qualification</center></th><th><center>Aadhar Id</center></th>";
echo "<th><center>Address</center></th><th><center>Contact</center></th><th><center>Action</center></th><th><center>Image</center></th></tr>";

$cnt=0;

while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$w_uname=$row["w_uname"];
	//$fname=$row["fname"];
	//$lname=$row["lname"];
	
	$nm = $row["fname"]." ".$row["lname"];
	$qualification=$row["qualification"];
	$area=$row["area"];
	$location=$row["location"];
	$contact=$row["contact"];

	echo "<tr>";
	echo "<td align='center'>$cnt</td>";
	echo "<td>&nbsp;".$row["w_uname"]."</td>";
	//echo "<td>&nbsp;".$row["fname"];
	
	echo "<td>&nbsp;".$nm."</td>";
	//echo "&nbsp;".$row["lname"]."</td>";
	
	echo "<td>&nbsp;".$row["qualification"]."</td>";
	echo "<td>&nbsp;".$row["aadhar_id"]."</td>";
	
	echo "<td>&nbsp;".$row["area"];
	echo ",&nbsp;".$row["location"]."</td>";
	echo "<td>&nbsp;".$row["contact"]."</td>";
	
	echo "<td>";
	echo "&nbsp;<a href='send_message_to_worker.php? w_uname=$w_uname&nm=$nm'>Send Message</a>";
	echo "&nbsp;<a href='del_all_worker.php?w_uname=$w_uname&nm=$nm'>&nbsp;&nbsp;&nbsp;&nbsp;Delete</a></td>";
	//echo "&nbsp;<a href='del_serviceman.php?w_uname=$w_uname&sid=$sid&sk=$sk''>Delete</a>";
	echo "<td>";
	echo "<a href='file_upload.php?w_uname=$w_uname'><img src='profile_pics/pic$w_uname.png' width='45px' /></a>";
	echo "</td>";
	
	echo "</tr>";
}

echo "</table></div>";

echo "<br><p><a href='admin.php'>Back to Panel</a></p>";

echo "<center>";

mysqli_close($con);
?>