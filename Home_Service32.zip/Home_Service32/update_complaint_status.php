<?php

include "header.php";
require "dbi.php";

$cid= $_POST["cid"];
$cdate=date("Y-m-d");
$status= $_POST["status"];

//$cname=strtoupper($_POST["cname"]);

$query="update complaint set cdate='$cdate',status='$status' where cid='$cid'";

mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	echo "<div class='well text-center'><h2 style='color:green'>Success:Status Updated</h2>";
	echo "<p><a href='worker.php'class='btn btn-primary'>Back To Panel</a></p></div>";
}
include "footer.php";
?>