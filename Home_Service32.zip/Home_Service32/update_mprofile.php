<?php
include "header.php";   // session started in header file - session_start();
include "dbi.php";

$fname=$_POST["fname"];
$lname=$_POST["lname"];
$area=$_POST["area"];
$location=$_POST["location"];
$contact=$_POST["contact"];
$udt=date("Y-m-d");


mysqli_query($con,"update member_profile set fname='$fname',lname='$lname',area='$area',location='$location',contact='$contact',udate='$udt' where m_uname='$uname'") or die(mysqli_error($con));
if(mysqli_affected_rows($con) > 0)
{
	echo "<div class='well text-center'><h2 style='color:green'>Success: Profile Updated!</h2>";
	echo "<p><a href='member.php'>Back To Panel</a></p></div>";
}

include "footer.php";
?>