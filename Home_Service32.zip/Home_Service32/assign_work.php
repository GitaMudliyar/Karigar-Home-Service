<?php
include "header.php";

//include "validate_worker.php";
?>
<style>
body{
	margin: 0;
	padding: 0;
	background : url(pic1.jpg); 
	background-size: cover;
	background-position: center;
	font-family: sans-serif;
}
</style>

<div class="panel panel-primary" style="max-width:300px;margin:auto">
		<div class="panel-heading">
			NEW COMPLAINT
		</div>

		<div class="panel-body panel-center">
		<?php
include "dbi.php";
$nm=$_GET["nm"];
$sid=$_GET["sid"];
$skill=$_GET["skill"];
$udt=date('Y-m-d');
$w_nm=$_GET["w_nm"];

if(!empty($uname))
{
	$result = mysqli_query($con,"select * from member_profile where m_uname='$uname'");

	if($row=mysqli_fetch_array($result))
	{
		$m_uname = $row["fname"]." ".$row["lname"];
		//$udt=date("Y-m-d");
		//$w_nm=$row["w_nm"];
	}
	else
	{
		$nm=""; 
		//$udt="";
	}

}


?>
	<form class="form" action="assign_work_insert.php" method="post">		

<div class="form-group">
<label for="nameField">Date</label>
<input type="text" readonly class="form-control input-sm" name="udt" value="<?php echo $udt;?>" />
</div>

<div class="form-group">
<label for="nameField">Your Name</label>
<input type="text" readonly class="form-control input-sm" value="<?php echo $m_uname;?>" name="m_uname" />
</div>


<input type="hidden" value="<?php echo $w_nm;?>" name="w_nm" />

<input type="hidden" value="<?php echo $uname;?>" name="uname" />

<div class="form-group">
<label for="nameField">Worker Name</label>
<input type="text" readonly class="form-control input-sm" value="<?php echo $nm;?>" name="w_uname" />
</div>

<div class="form-group">
<label for="nameField">Status</label>
<input type="text" readonly class="form-control input-sm" value="<?php echo 'COMPLAINT';?>" name="status"/>
</div>


<input type="hidden" name="sid" value="<?php echo $sid;?>" />
<input type="hidden" name="skill" value="<?php echo $skill;?>" />
<input type="hidden" name="nm" value="<?php echo $nm;?>" />

<div class="form-group">
<label for="nameField">More Details to <?php echo $skill ?></label>
<textarea class="form-control input-sm" cols="50" rows="5" name="details" placeholder="Work Related Details"></textarea>
</div>




<input type="submit" class="btn btn-success btn-block" value="Assign" /> 
</form>
		</div>

		<div class="panel-footer text-center">
			
<a href="member_view_serviceman.php">Back To Panel</a>
		</div>

	</div>


<?php
include "footer.php";
?>