<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>

<?php
include "header.php";
require "dbi.php";

$query="select * from service_master order by sid";

$result = mysqli_query($con,$query) or die(mysqli_error($con));

echo "<center>";

//echo "<p><a href='new_service.php'>New Service</a></p>";

echo "<p><a href='member.php'>Back</a></p>";
echo '<div class="table-responsive">';
echo '<table border>';
echo "<tr bgcolor='ChartReuse'><th><center>Sr. No.</center></th><th><center>Service</center></th><th><center>Action</center></th></tr>";

$cnt=0;

while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$id=$row["sid"];
	$service_type=$row["service_type"];

	echo "<tr>";
	echo "<td align='center'>$cnt</td>";
	echo "<td>&nbsp;".$row["service_type"]."</td>";

	echo "<td>";
	echo "&nbsp;<a href='member_view_serviceman.php?sid=$id&sk=$service_type'>View Workers</a>";
	echo "</td>";

	echo "</tr>";
}

echo "</table></div>";

//echo "<p><a href='workers_list.php'>Worker(s) List</a></p>";

echo "<center>";

mysqli_close($con);
?>