<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>

<?php
$sid= $_GET["sid"];
include "header.php";
require "dbi.php";


$query="select * from service_master where sid=$sid";

$result=mysqli_query($con,$query) or die(mysqli_error($con));

if($row=mysqli_fetch_array($result))
{
	$service_type=$row["service_type"];
}
else
{
	echo "<center><h2>Service Not Found</h2>";
	echo "<p><a href='service_list.php'>Back to List</a></p></center>";
	exit;
}

?>
<html>

<body>
<center>
<p><a href='service_list.php'>Back to List</a></p>


<form action="update_service.php" method="post">
<div class="table-responsive">
<table>
<tr bgcolor='deepPink'><td colspan="2" align='center'>
UPDATE SERVICE
</td>
</tr>

<tr>
<td>SID:</td>
<td><input type="text" name="sid" readonly value="<?php echo $sid; ?>" /></td>
</tr>

<tr>
<td>Enter Service:</td>
<td><input type="text" name="service_type" value="<?php echo $service_type; ?>" /></td>
</tr>

<tr bgcolor='thistle'><td colspan="2" align='center'>
<input type="submit"  value="Update Service"/>
</td>
</tr>

</table></div>
</form>
</center>
</body>
</html>