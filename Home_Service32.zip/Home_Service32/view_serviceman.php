<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>

<?php
$sid = $_GET["sid"];
$sk = $_GET["sk"];


include "header.php";
include "dbi.php";


$skill=$_GET["sk"];

$query = "select * from worker_profile where w_uname in (select w_uname from v_skills where service_type='$sk')";

$skill=strtoupper($skill);
$result=mysqli_query($con,$query);
echo "<p><center><a href='service_list.php'> Back </a></center></p>";
echo "<h2 class='text-center'>$skill</h2>";
echo '<div class="table-responsive">';
echo '<table border>';
echo "<tr bgcolor='DeepPink'><th><center>Sr. No. </center></th><th><center>Name</center></th>";
echo "<th><center>City</center></th><th><center>Image</center></th><th><center>Action</th></tr>";

$cnt=0;

while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$w_uname=$row["w_uname"];
	$nm = $row["fname"]." ".$row["lname"];

	echo "<tr>";
	echo "<td>".$cnt."</td>";
	echo "<td>".$nm."</td>";
	echo "<td>".$row["location"]."</td>";

	echo "<td>";
	//echo "<a href='file_upload.php?w_uname=$w_uname'>";
	echo "<img src='profile_pics/pic$w_uname.png' width='45px' /></a>";
	echo "</td>";
	
	echo "<td>";
	echo "&nbsp;<a href='view_worker_details.php?w_uname=$w_uname&sid=$sid&sk=$sk'>Details</a>";
	echo "&nbsp;<a href='send_message.php?sk=$sk&w_uname=$w_uname&sid=$sid&sk=$sk&nm=$nm''>Send Message</a>";
	echo "&nbsp;<a href='del_serviceman.php?w_uname=$w_uname&sid=$sid&sk=$sk'>Delete</a>";
	//echo "&sk=$service_type'>Delete</a>";
	echo "</td>";
	
	echo "</tr>";
	
}


echo "</table></div>";

mysqli_close($con);

/*$query="select * from service_provider where sid=$sid";

$result = mysqli_query($con,$query) or die(mysqli_error($con));
echo "<center>";

echo "<p><a href='service_list.php>Back To Service List</a></p>";

$total = mysqli_num_rows($result);

echo "<h3>".strtoupper($service_type).": $total Worker(s)</h3>";
echo "<div class='table-responsive'><table>";
echo "<tr bgcolor='DeepPink'><th><center>Sr.No.</center></th><th><center>Serviceman</center></th><th><center>Action</center></th>";
echo "<th><center>Image</center></th>";

$cnt=0;

while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$id=$row["w_uname"];

	echo "<tr>";
	echo "<td align='center'>$cnt</td>";
	echo "<td>&nbsp;".$row["w_uname"]."</td>";
	echo "<td>";
	echo "&nbsp;<a href='view_worker_details.php'>Details</a>";
	echo "&nbsp;<a href='dummy.php?wn=$id'>Send Message</a>";
	echo "&nbsp;<a href='del_worker.php?wn=$id'>Remove</a>";
	echo "</td>";
	
	echo "<td>";
	//echo "<a href='file_upload.php?w_uname=$w_uname'>";
	echo "<img src='home_pics/pic$sid.png' width='45px' /></a>";
	echo "</td>";
	echo "</tr>";
}

echo "</table></div><center>";

mysqli_close($con);
*/
?>