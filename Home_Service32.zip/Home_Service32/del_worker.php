<?php
include "header.php";
$spid= $_GET["spid"];

require "dbi.php";


$query="select * from service_provider where spid=$spid";

$result=mysqli_query($con,$query) or die(mysqli_error($con));

if($row=mysqli_fetch_array($result))
{
	$s_uname=$row["s_uname"];
}
else
{
	echo "<center><h2>Worker Not Found</h2>";
	echo "<p><a href='view_serviceman.php'>Back to List</a></p></center>";
	exit;
}

?>
<html>
<body>
<center>
<p><a href='view_serviceman.php'>Back to List</a></p>

<form action="delete_worker.php" method="post">

<?php
	echo "<h2 style='color:red'>Delete Worker:- $s_uname @ SPID: $spid</h2>";
	echo "<h2>Are You Sure?</h2>";

?>

<input type="hidden" name="spid" value="<?php echo $spid; ?>" />


<input type="submit"  value="Confirm Delete"/>

</form>
</center>
</body>
</html>