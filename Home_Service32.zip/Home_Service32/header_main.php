<!--index1.php-->


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Karigar Home Service</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link href="css/styles.css" rel="stylesheet">

<style>
body{
background-color:gainsboro;
}

</style>
</head>
<body>


<div class="container">
	<div style="height:200px" id="bestCarsCarousel" class="carousel slide" data-ride="carousel">
<!-- Indicators -->
<ol class="carousel-indicators">
<li data-target="#bestCarsCarousel" data-slide-to="0" class="active"></li>
<li data-target="#bestCarsCarousel" data-slide-to="1"></li>
<li data-target="#bestCarsCarousel" data-slide-to="2"></li>
<li data-target="#bestCarsCarousel" data-slide-to="3"></li>
</ol>
<!-- Wrapper for slides -->
<div class="carousel-inner">
<div class="item active">
<?php
include "carouse.php";
include "header.php";
?>
   <!-- <div class="navbar navbar-inverse">
	<div class="container-fluid">
	<div class="navbar-header">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mynavbar-content">
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		</button>

	<a class="navbar-brand" href="#">Karigar</a>
	</div>
		<div class="collapse navbar-collapse" id="mynavbar-content">
			<ul class="nav navbar-nav">
				<li class="active"><a href="index1.php">Home</a></li>
				<li class="dropdown">
				  <a href="#" class="dropdown-toggle" data-toggle="dropdown"> About Us<b class="caret"></b></a>
					<ul class="dropdown-menu">
						<li><a href="#">Board of Members</a></li>
						<li><a href="#">Developers Team</a></li>
						<li><a href="#">Designing Team</a></li>
						<li class="divider"></li>
						<li><a href="#">Login</a></li>
						<li><a href="#">Registration</a></li>
					</ul>
				</li>
				
				
				
				<li><a href="#">Admin</a></li>
				<li><a href="login.php">Member</a></li>
				<li><a href="wlogin.php">Worker</a></li>
				<li><a href="#">Login</a></li>
				<li><a href="#">Contact Us</a></li>
				<li><a href="#">Feedback</a></li>
			</ul>	
		</div>
	</div>
</div>-->