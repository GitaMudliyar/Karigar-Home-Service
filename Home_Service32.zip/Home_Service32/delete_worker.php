<?php
$spid= $_POST["spid"];

require "dbi.php";

$query="delete from service_provider where spid=$spid";

mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	header("location:view_serviceman.php");
}

?>