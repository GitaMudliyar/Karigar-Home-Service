<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>

<?php
include "header.php";   // require "header.php";
include "dbi.php";
$skill=$_GET["sk"];
$sid=$_GET["sid"];

$query = "select * from worker_profile where w_uname in (select w_uname from v_skills where service_type='$skill')";

$skill=strtoupper($skill);
$result=mysqli_query($con,$query);

echo "<p><center><a href='member_service_list.php'> Back </a></center></p>";
echo "<h2 class='text-center'>$skill</h2>";

echo '<div class="table-responsive">';
echo '<table border>';
echo "<tr bgcolor='ChartReuse'><th><center>Sr.No.</center></th><th><center>Name</center></th>";
echo "<th><center>City</center></th><th><center>Assign Work</center></th></tr>";

$cnt=0;

while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$w_uname=$row["w_uname"];
	$nm = $row["fname"]." ".$row["lname"];

	echo "<tr>";
	echo "<td>".$cnt."</td>";
	echo "<td>".$nm."</td>";
	echo "<td>".$row["location"]."</td>";
	
	echo "<td>&nbsp;<a href='assign_work.php?sid=$sid&nm=$nm&skill=$skill&w_nm=$w_uname'>Assign Work</a></td>";
//echo "$w_uname";
	echo "</tr>";
	
}


echo "</table></div>";
 ?>


 
 <?php
include "footer.php";   // require "header.php";
 ?>