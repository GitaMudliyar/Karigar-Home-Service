<?php
$m_uname= $_POST["m_uname"];

require "dbi.php";

$query="delete from member_profile where m_uname='$m_uname'";

mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	header("location:view_all_members.php");
}

?>