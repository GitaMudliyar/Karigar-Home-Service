<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>

<?php
include "header.php";
include "dbi.php";

$filter = isset($_POST["filter"])?$_POST["filter"]:"";
$btn = isset($_POST["btn"])?$_POST["btn"]:"";

if(empty($filter) || $btn=="Show All")
{
	$query="select * from v_skills order by service_type";
	$filter="";
}
else
{
	$query="select * from v_skills where w_uname like '%$filter%' order by service_type";
}

$result = mysqli_query($con,$query) or die(mysqli_error($con));
echo "<center>";

echo "<p><a href='service_list.php'>Back</a></p>";



?>
<p>
<form action="workers_list.php" method="post">
<center>
Search Name : <input type="text" name="filter" value="<?php echo $filter; ?>" /> 
<input type="submit" value="Filter" name="btn" />
<input type="submit" value="Show All" name="btn" />
</center>
</form>
</p>
<?php
echo '<div class="table-responsive">';
echo "<table border='1'>";
echo "<tr bgcolor='deepPink'><th><center>Sr. No.</center></th><th><center>Service Type</center></th>";
echo "<th><center>User Name</center></th><th><center>Image</center></th></tr>";

$cnt=0;

while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$w_uname=$row["w_uname"];

	echo "<tr>";
	echo "<td align='center'>$cnt</td>";
	echo "<td>&nbsp;".$row["service_type"]."</td>";
	echo "<td>&nbsp;".$row["w_uname"]."</td>";
	
	echo "<td>";
	//echo "<a href='file_upload.php?w_uname=$w_uname'>";
	echo "<img src='profile_pics/pic$w_uname.png' width='45px' /></a>";
	echo "</td>";


	echo "</tr>";
}

echo "</table>";
echo "</div></center>";

mysqli_close($con);
?>