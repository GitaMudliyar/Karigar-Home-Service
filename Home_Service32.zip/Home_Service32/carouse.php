<div class="container">
<div style="height:200px" id="bestCarsCarousel" class="carousel slide" data-ride="carousel">
<!-- Indicators -->
<ol class="carousel-indicators">
<li data-target="#bestCarsCarousel" data-slide-to="0" class="active"></li>
<li data-target="#bestCarsCarousel" data-slide-to="1"></li>
<li data-target="#bestCarsCarousel" data-slide-to="2"></li>
<li data-target="#bestCarsCarousel" data-slide-to="3"></li>
</ol>
<!-- Wrapper for slides -->
<div class="carousel-inner">
<div class="item active">
<img src="images/house1.jpg">
<div class="carousel-caption">
<!--<h3>Car 1</h3>
<p>Lorem ipsum dolor sit amet, consectetur ...</p>-->
</div>
</div>
<div class="item">
<img src="images/house2.jpg">
<div class="carousel-caption">
<!--<h3>Karigar</h3>
<p>We together form a family</p>-->
</div>
</div>
<div class="item">
<img src="images/house3.jpg">
<div class="carousel-caption" >
<!--<p>We provide almost all kinds of housing services ...</p>-->
</div>
</div>
</div>
<!-- Controls -->
<a class="left carousel-control" href="#bestCarsCarousel" data-slide="prev">
<span class="glyphicon glyphicon-chevron-left"></span>
</a>
<a class="right carousel-control" href="#bestCarsCarousel" data-slide="next">
<span class="glyphicon glyphicon-chevron-right"></span>
</a>
</div>