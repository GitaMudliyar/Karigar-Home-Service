<style>
body
{
	background-color:gainsboro;
}
</style>

<html>
<body>
  <div class="well" style="background-color:lavender">
	<center><p style='color:Crimson' ><b><i>Developed by Nikita Kadapure and Gita Mudliyar</i><b> </p></center>
</div>
</div>


<script src="js/jquery.js"></script>
<script src="js/bootstrap.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        var options = {
            interval: 3000,
            pause: 'hover',
            wrap: true
        };
        $('#bestCarsCarousel').carousel(options);
    });
</script>
</body>
</html>