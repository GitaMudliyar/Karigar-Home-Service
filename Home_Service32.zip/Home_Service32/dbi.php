
<?php

	// mysql, user,pwd,database
 $con = mysqli_connect("localhost","root","","home_service_db") or die(mysqli_error($con));

?>