<?php
	
if(!isset($_SESSION["uname"]))
{
	header("location:login.php");
	exit;
}
else if($_SESSION["role"] !="worker")
{
	header("location:login.php");
	exit;
}

?>