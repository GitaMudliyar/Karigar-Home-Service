<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>


<?php
include "header.php"
?>

<html>
<body>
<center>
<p><a href='service_list.php'>Back to List</a></p>


<form action="insert_service.php" method="post">
<div class="table-responsive">
<table border>
<tr bgcolor="DeepPInk"><td colspan="2" align='center'>
NEW SERVICE
</td></tr>
<tr>
<td>Enter Service:-</td>
<td><input type="text" name="service_type" /></td></tr>
<tr bgcolor='Thistle'><td colspan="2" align='center'>
<input type="submit"  value="Add SERVICE"/>
</td>
</tr>
</table></div>
</form>
</center>
</body>
</html>