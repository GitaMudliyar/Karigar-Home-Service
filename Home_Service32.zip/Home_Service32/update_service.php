<?php
$sid= $_POST["sid"];
$service_type= $_POST["service_type"];

require "dbi.php";

$service_type=strtoupper($_POST["service_type"]);

$query="update service_master set service_type='$service_type' where sid=$sid";

mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	header("location:service_list.php");
}

?>