<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>

<?php
include "header.php";
require "dbi.php";
$cid= $_GET["cid"];
//$cid=$_POST["cid"];
   $query="select * from complaint where cid=$cid";
   
  $result=mysqli_query($con,$query) or die(mysqli_error($con));


if($row=mysqli_fetch_array($result))
{
   $cid=$row["cid"];
    $cdate=$row["cdate"];
	//$m_uname=$row["m_uname"];
	//$category=$row["category"];
	//$c_detail=$row["c_detail"];
	$status=$row["status"];
}
else
{
	echo "<center><h2>Complaint Not Found</h2>";
	echo "<p><a href='w_view_complaints'>Back</a></p></center>";
	exit;
}


?>

<html>
<body>

<center>
<p><a href='w_view_complaints.php' '>Back to List</a></p>
<?php
$cid= $_GET["cid"];
//$cid=$_POST["cid"];
   $query="select * from complaint where cid=$cid";
   
  $result=mysqli_query($con,$query) or die(mysqli_error($con));


if($row=mysqli_fetch_array($result))
{
   $cid=$row["cid"];
    $cdate=$row["cdate"];
	//$m_uname=$row["m_uname"];
	//$category=$row["category"];
	//$c_detail=$row["c_detail"];
	$status=$row["status"];
}
else
{
	echo "<center><h2>Complaint Not Found</h2>";
	echo "<p><a href='view_complaint.php' class='btn btn-info btn-sm'>Back to List</a></p></center>";
	exit;
}


?>


<form action="update_complaint_status.php" method="post">
<div class="table-responsive">
<table border="1">
<tr bgcolor='DarkCyan'><td colspan="2" align='center'>EDIT COMPLAINT</td></tr>

<tr>
<td>CID:</td>
<td><input type="text" name="cid" readonly value="<?php echo $cid; ?>" /></td>
</tr>
<tr>
<td>Date:</td>
<td><input type="date" name="cdate" value="<?php echo $cdate; ?>" /></td>
</tr>

<tr>
<td>Select Status:</td>
<td>
<select name="status">

<option <?php echo($status=='IN PROGRESS')?"selected":"";?>>IN PROGRESS</option>
<option <?php echo($status=='COMPLETED')?"selected":"";?>>COMPLETED</option>
<option <?php echo($status=='RECEIVED')?"selected":"";?>>RECEIVED</option>
<option <?php echo($status=='DENIED')?"selected":"";?>>DENIED</option>

</select>

</td>
</tr>



<tr><td colspan="2" align='center'>
<input type="submit"  value="Update Complaint" class='btn btn-primary'/>
</td>
</tr>
</table>
</div>
</form>
</center>
<?php
include "footer.php";
?>
</body>
</html>