<?php
require "header.php";
require "dbi.php";

$udt=$_POST["udt"];
$m_uname=$_POST["m_uname"];
$w_uname=$_POST["w_uname"];
$sid=$_POST["sid"];
$details=$_POST["details"];

//$m_nm=$_POST["uname"];
$nm=$_POST["nm"];
$w_nm=$_POST["w_nm"];
$skill=$_POST["skill"];

$query="insert into complaint(cdate,m_nm,m_uname,w_nm,w_uname,sid,service_type,details,status) values('$udt','$uname','$m_uname','$w_nm','$w_uname','$sid','$skill','$details','COMPLAINT')";
//,'$w_uname',$sid,'$details')";

mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con)>0)
{
	echo "<div class='well text-center'><h2 style='color:green'>Success: You Hired $skill $nm</h2>";
	echo "<h4 style='color:maroon'>Our Worker Will Contact You Soon !!!</h4>";
	echo "<p><a href='member.php'>Back To Panel</a></p></div>";
}
include "footer.php";
?>