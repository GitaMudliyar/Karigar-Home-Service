<?php
$sid= $_POST["sid"];

require "dbi.php";

$query="delete from service_master where sid=$sid";

mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	header("location:service_list.php");
}

?>