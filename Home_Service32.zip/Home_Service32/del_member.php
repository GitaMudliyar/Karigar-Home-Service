<?php
include "header.php";
$m_uname= $_GET["m_uname"];
$nm=$_GET["nm"];

require "dbi.php";


$query="select * from member_profile where m_uname='$m_uname'";

$result=mysqli_query($con,$query) or die(mysqli_error($con));

if($row=mysqli_fetch_array($result))
{
	$m_uname=$row["m_uname"];
}
else
{
	echo "<center><h2>Member Not Found</h2>";
	echo "<p><a href='view_all_members.php'>Back</a></p></center>";
	exit;
}

?>
<html>
<body>
<center>
<p><a href='view_all_members.php'>Back to List</a></p>

<form action="delete_member.php" method="post">

<?php
	echo "<h2 style='color:red'>Remove Member $nm</h2>";
	echo "<h2>Are You Sure?</h2>";

?>

<input type="hidden" name="m_uname" value="<?php echo $m_uname; ?>" />


<input type="submit"  value="Confirm Delete"/>

</form>
</center>
</body>
</html>