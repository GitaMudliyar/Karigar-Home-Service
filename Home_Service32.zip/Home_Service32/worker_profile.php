<?php
include "header.php";

include "validate_worker.php";
?>
<style>
body{
	margin: 0;
	padding: 0;
	background : url(pic1.jpg); 
	background-size: cover;
	background-position: center;
	font-family: sans-serif;
}
</style>

<div class="panel panel-primary" style="max-width:300px;margin:auto">
		<div class="panel-heading">
			Worker Profile
		</div>

		<div class="panel-body panel-center">
		<?php
include "dbi.php";

if(!empty($uname))
{
	$result = mysqli_query($con,"select * from worker_profile where w_uname='$uname'");

	if($row=mysqli_fetch_array($result))
	{
		
$fn=$row["fname"];
$ln=$row["lname"];
$age=$row["age"];
$gender=$row["gender"];
$qual=$row["qualification"];
$aadhar_id=$row["aadhar_id"];
$area=$row["area"];
$location=$row["location"];
$contact=$row["contact"];
$udt=date("Y-m-d");
	}
	else
	{
		$fn=""; $ln=""; $age=""; $gender=""; $qual=""; $aadhar_id=""; $area=""; $location=""; $contact=""; $udt="";
	}

}


?>
	<form class="form" action="update_wprofile.php" method="post">		

<div class="form-group">
<label for="nameField">Profile Picture</label><br>
<center>
<a href="file_upload.php?w_uname=<?php echo $uname; ?>"><img src="profile_pics/pic<?php echo $uname; ?>.png" width="100px" height="100px"/></a>
</center>
</div>


<div class="form-group">
<label for="nameField">First Name</label>
<input type="text" class="form-control input-sm" required value="<?php echo $fn;?>" name="fname" placeholder="First Name" />
</div>

<div class="form-group">
<label for="nameField">Last Name</label>
<input type="text" class="form-control input-sm" required value="<?php echo $ln;?>" name="lname" placeholder="Last Name" />
</div>

<div class="form-group">
<label for="nameField">Age</label>
<input type="text" class="form-control input-sm" value="<?php echo $age;?>" name="age" placeholder="Age" />
</div>

<div class="form-group">
<label for="nameField">Gender</label>
<input type="text" class="form-control input-sm" value="<?php echo $gender;?>" name="gen" placeholder="Gender" />
</div>

<div class="form-group">
<label for="nameField">Qualification</label>
<input type="text" class="form-control input-sm" value="<?php echo $qual;?>" name="qlf" placeholder="Qualification Details" />
</div>

<div class="form-group">
<label for="nameField">Aadhar Id</label>
<input type="text" class="form-control input-sm" required value="<?php echo $aadhar_id;?>" name="aadhar_id" maxLength=12 placeholder="Aadhar Card Details" />
</div>


<div class="form-group">
<label for="nameField">Area</label>
<input type="text" class="form-control input-sm" required value="<?php echo $area;?>" name="area" placeholder="Area" />
</div>

<div class="form-group">
<label for="nameField">Location</label>
<input type="text" class="form-control input-sm" required value="<?php echo $location;?>" name="loc" placeholder="City" />
</div>

<div class="form-group">
<label for="nameField">Contact</label>
<input type="text" class="form-control input-sm" value="<?php echo $contact;?>" name="contact" placeholder="Address" />
</div>

<div class="form-group">
<label for="nameField">Updated on</label>
<input type="text" readonly class="form-control input-sm" name="udate" placeholder="Updated Date" />
</div>


<input type="submit" class="btn btn-warning btn-block" value="Update Profile" /> 
</form>
		</div>

		<div class="panel-footer text-center">
			
<a href="worker.php">Back To Panel</a>
		</div>

	</div>


<?php
include "footer.php";
?>




