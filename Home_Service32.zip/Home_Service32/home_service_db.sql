-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 11, 2020 at 05:41 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `home_service_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `complaint`
--

CREATE TABLE IF NOT EXISTS `complaint` (
  `cid` int(10) NOT NULL AUTO_INCREMENT,
  `cdate` date DEFAULT NULL,
  `m_nm` varchar(50) DEFAULT NULL,
  `m_uname` varchar(50) DEFAULT NULL,
  `w_nm` varchar(50) DEFAULT NULL,
  `w_uname` varchar(50) DEFAULT NULL,
  `sid` int(10) DEFAULT NULL,
  `service_type` varchar(50) DEFAULT NULL,
  `details` varchar(50) DEFAULT NULL,
  `status` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `complaint`
--

INSERT INTO `complaint` (`cid`, `cdate`, `m_nm`, `m_uname`, `w_nm`, `w_uname`, `sid`, `service_type`, `details`, `status`) VALUES
(40, '2020-03-06', 'Gita', 'Gita Mudliyar', 'jagan', 'Tony Stark', 3, 'PAINTER', 'Paint Stair Case', 'COMPLETED'),
(35, '2020-03-06', 'nik', 'Nikita Kadapure', 'w', 'Gita Mudliyar', 5, 'POOL CLEANER', 'Clean Pool', 'COMPLETED'),
(34, '2020-03-06', 'nik', 'Nikita Kadapure', 'w', 'Gita Mudliyar', 5, 'POOL CLEANER', 'Clean Pool', 'COMPLETED'),
(39, '2020-03-06', 'Gita', 'Gita Mudliyar', 'jagan', 'Tony Stark', 2, 'ELECTRICIAN', 'Repair Television', 'COMPLAINT'),
(33, '2020-03-06', 'nik', 'Nikita Kadapure', 'w', 'Gita Mudliyar', 5, 'POOL CLEANER', 'Clean Pool', 'DENIED'),
(32, '2020-03-06', 'nik', 'Nikita Kadapure', 'w', 'Gita Mudliyar', 5, 'POOL CLEANER', 'Clean Pool', 'COMPLAINT'),
(36, '2020-03-06', 'radha', 'radha Krishna', 'Sweety', 'Sweety Halwai', 4, 'INTERIOR DECORATOR', 'Decorate my Home', 'COMPLAINT'),
(37, '2020-03-06', 'radha', 'radha Krishna', 'nikita', 'NIkita Kadapure', 3, 'PAINTER', 'Paint backyard', 'COMPLETED'),
(38, '2020-03-06', 'm', 'Man Singh', 'jagan', 'thanos ------', 2, 'ELECTRICIAN', 'haad', 'COMPLETED'),
(31, '2020-03-06', 'm', 'Man Singh', 'w', 'Gita Mudliyar', 1, 'CARPENTER', 'body', 'COMPLAINT'),
(41, '2020-03-06', 'm', 'Man Singh', 'jagan', 'Tony Stark', 2, 'ELECTRICIAN', 'Electric works', 'COMPLAINT'),
(42, '2020-03-09', 'radha', 'radha Krishna', 'Chanda', 'Chandrakant Patil', 12, 'PLUMBER', 'Repair tap', 'COMPLETED'),
(43, '2020-03-09', 'pooja', 'Pooja Khore', 'w', 'Gita Mudliyar', 2, 'ELECTRICIAN', 'Repair TV', 'COMPLAINT');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `fid` int(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) DEFAULT NULL,
  `e_mail` varchar(25) DEFAULT NULL,
  `u_date` date DEFAULT NULL,
  `comments` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`fid`, `name`, `e_mail`, `u_date`, `comments`) VALUES
(1, 'happy', 'happy@sad.com', '2020-02-22', 'hi'),
(2, 'Gayatri', 'happy@sad.com', '2020-02-23', 'Save'),
(3, 'Girish', 'happy@sad.com', '2020-02-26', 'Whats the matter'),
(4, 'Girish', 'gita@gmail.com', '2020-03-06', 'Thank you'),
(6, 'Nikhil Kadapure', 'nik@gmail.com', '2020-03-09', 'Had a nice experience');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `uname` varchar(25) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  `role` varchar(25) NOT NULL,
  `created_at` date NOT NULL,
  `see_ans` varchar(50) NOT NULL,
  `security_question` varchar(50) NOT NULL,
  PRIMARY KEY (`uname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`uname`, `pwd`, `role`, `created_at`, `see_ans`, `security_question`) VALUES
('ad', 'ad', 'admin', '0000-00-00', '', ''),
('Pranit', 'p', 'worker', '2020-03-09', '', ''),
('aq', 'aq', 'worker', '2020-02-24', '', ''),
('w', 'w', 'worker', '2020-02-12', '', ''),
('Gita', 'g', 'member', '2020-02-23', '', ''),
('Sweety', 's', 'worker', '2020-02-27', '', ''),
('m', 'm', 'member', '2020-02-27', '', ''),
('monika', 'm', 'worker', '2020-03-01', '', ''),
('nikita', 'n', 'worker', '2020-03-03', '', ''),
('jag', 'j', 'worker', '2020-03-05', '', ''),
('radha', 'r', 'member', '2020-03-05', '', ''),
('pooja', 'p', 'member', '2020-03-09', '', ''),
('jagan', 'jagan1', 'worker', '2020-03-06', '', ''),
('suddatta', '123', 'member', '2020-03-06', '', ''),
('Chanda', 'c', 'worker', '2020-03-09', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `member_profile`
--

CREATE TABLE IF NOT EXISTS `member_profile` (
  `m_uname` varchar(25) NOT NULL,
  `fname` varchar(25) DEFAULT NULL,
  `lname` varchar(25) DEFAULT NULL,
  `area` varchar(50) DEFAULT NULL,
  `location` varchar(50) DEFAULT NULL,
  `contact` varchar(50) DEFAULT NULL,
  `udate` date NOT NULL,
  PRIMARY KEY (`m_uname`),
  UNIQUE KEY `contact` (`contact`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member_profile`
--

INSERT INTO `member_profile` (`m_uname`, `fname`, `lname`, `area`, `location`, `contact`, `udate`) VALUES
('suddatta', 'suddatta', 'muddegol', 'M.G.Road', 'Miraj', 'jhjhjhj', '2020-03-06'),
('Gita', 'Gita', 'Mudliyar', 'Janawade Malla', 'Miraj', '9021094915', '2020-02-26'),
('m', 'Man', 'Singh', 'Sarf Katta', 'Miraj', '5647897889', '2020-02-27'),
('radha', 'radha', 'Krishna', '54', 'MG Road', 'Brindawan', '2020-03-06'),
('pooja', 'Pooja', 'Khore', 'Shivaji Nagar', 'Miraj', '9876543219', '2020-03-09');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `mid` int(12) NOT NULL AUTO_INCREMENT,
  `f_uname` varchar(50) DEFAULT NULL,
  `from_u` varchar(25) DEFAULT NULL,
  `t_uname` varchar(50) DEFAULT NULL,
  `to_u` varchar(25) DEFAULT NULL,
  `mdate` date DEFAULT NULL,
  `subject` varchar(200) DEFAULT NULL,
  `contents` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`mid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=109 ;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`mid`, `f_uname`, `from_u`, `t_uname`, `to_u`, `mdate`, `subject`, `contents`) VALUES
(1, NULL, 'w', NULL, 'ad', '2020-03-10', 'hi', 'bye'),
(2, NULL, 'ad', NULL, 'w', '2020-03-05', 'Work', 'Need to work a lot'),
(97, 'm', 'Man Singh', 'ad', 'Admin', '2020-03-07', 'Hello', 'Hello Sir'),
(106, 'w', 'Gita Mudliyar', 'ad', 'Admin', '2020-03-07', 'You have an excellent worker', 'You have an excellent hard working worker'),
(94, 'ad', 'Admin', 'Sweety', 'Sweety Halwai', '2020-03-07', 'To complete work within time', 'Mam we have received complaint about you  that you are not in time'),
(92, 'ad', 'Admin', 'suddatta', 'suddatta muddegol', '2020-03-07', 'Work to done within a week', 'Sir your work will be done within a week'),
(84, 'w', 'Gita Mudliyar', 'nik', 'Nikita Kadapure', '2020-03-07', 'A thanking letter', 'Thanks for your response'),
(89, 'm', 'Man Singh', 'w', 'Gita Mudliyar', '2020-03-07', 'Payment to be delivered late', 'Mam due to certain unpredicted circumstances your payment will be made late'),
(88, 'm', 'Man Singh', 'jagan', 'Tony Stark', '2020-03-07', 'Thank you for selecting me', 'Sir Thank You for hiring me for your work'),
(87, 'w', 'Gita Mudliyar', 'm', 'Man Singh', '2020-03-07', 'To be in time', 'Sir please be on time tommorow'),
(86, 'w', 'Gita Mudliyar', 'm', 'Man Singh', '2020-03-07', 'Increase in estimated cost', 'Hello sir the cost that we estimated had been increased'),
(85, 'w', 'Gita Mudliyar', 'nik', 'Nikita Kadapure', '2020-03-07', 'A thanking letter', 'Thanks for your response'),
(108, 'Chanda', 'Chandrakant Patil', 'ad', 'Admin', '2020-03-09', 'Will be unable to attend meeting', 'Will be unable to attend online meeting');

-- --------------------------------------------------------

--
-- Table structure for table `service_master`
--

CREATE TABLE IF NOT EXISTS `service_master` (
  `sid` int(5) NOT NULL AUTO_INCREMENT,
  `service_type` varchar(30) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `service_master`
--

INSERT INTO `service_master` (`sid`, `service_type`) VALUES
(1, 'CARPENTER'),
(2, 'ELECTRICIAN'),
(3, 'PAINTER'),
(4, 'INTERIOR DECORATOR'),
(5, 'POOL CLEANER'),
(6, 'TILES FIXER'),
(9, 'TREE SHAPER'),
(12, 'PLUMBER');

-- --------------------------------------------------------

--
-- Table structure for table `service_provider`
--

CREATE TABLE IF NOT EXISTS `service_provider` (
  `spid` int(5) NOT NULL AUTO_INCREMENT,
  `sid` int(5) NOT NULL,
  `w_uname` varchar(50) NOT NULL,
  PRIMARY KEY (`spid`),
  UNIQUE KEY `sid` (`sid`,`w_uname`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=61 ;

--
-- Dumping data for table `service_provider`
--

INSERT INTO `service_provider` (`spid`, `sid`, `w_uname`) VALUES
(25, 3, 'n'),
(48, 2, 'w'),
(43, 1, 'nikita'),
(32, 1, 'w'),
(26, 1, 'aq'),
(27, 9, 'w'),
(28, 5, 'w'),
(29, 6, 'Sweety'),
(30, 4, 'monika'),
(31, 9, 'monika'),
(44, 3, 'nikita'),
(34, 3, 'w'),
(35, 4, 'w'),
(45, 6, 'nikita'),
(37, 9, 'n'),
(38, 3, 'aq'),
(39, 6, 'aq'),
(40, 9, 'aq'),
(41, 1, 'monika'),
(42, 3, 'monika'),
(46, 9, 'nikita'),
(47, 1, 'n'),
(49, 4, 'Sweety'),
(50, 2, 'Sweety'),
(51, 9, 'Sweety'),
(52, 2, 'jagan'),
(53, 9, 'jagan'),
(54, 3, 'jagan'),
(55, 1, 'jagan'),
(56, 1, 'Chanda'),
(57, 12, 'Chanda'),
(58, 12, 'Pranit'),
(59, 6, 'Pranit'),
(60, 1, 'Pranit');

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_skills`
--
CREATE TABLE IF NOT EXISTS `v_skills` (
`service_type` varchar(30)
,`w_uname` varchar(50)
);
-- --------------------------------------------------------

--
-- Table structure for table `worker_profile`
--

CREATE TABLE IF NOT EXISTS `worker_profile` (
  `w_uname` varchar(25) NOT NULL,
  `fname` varchar(25) DEFAULT NULL,
  `lname` varchar(25) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `gender` varchar(8) DEFAULT NULL,
  `qualification` varchar(20) DEFAULT NULL,
  `aadhar_id` varchar(20) DEFAULT NULL,
  `area` varchar(25) DEFAULT NULL,
  `location` varchar(25) DEFAULT NULL,
  `contact` varchar(50) DEFAULT NULL,
  `udate` date DEFAULT NULL,
  PRIMARY KEY (`w_uname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `worker_profile`
--

INSERT INTO `worker_profile` (`w_uname`, `fname`, `lname`, `age`, `gender`, `qualification`, `aadhar_id`, `area`, `location`, `contact`, `udate`) VALUES
('w', 'Gita', 'Mudliyar', 21, 'Female', 'MCA-II', '828260022026', 'Samtanagar', 'Miraj', '9021094915', '2020-03-07'),
('Sweety', 'Sweety', 'Halwai', 32, 'Female', '', '214748364702', 'Kantap Plot', 'Miraj', 'sweety@gmail.com', '2020-03-07'),
('monika', 'Monika', 'Hasabe', 22, 'Female', 'MCA', '147483647302', 'Hanumant Nagar', 'VIta', '87845623215', '2020-03-07'),
('nikita', 'NIkita', 'Kadapure', 22, 'Female', 'MBA', '214748364713', 'ap', 'Mhaishal', '7845456545', '2020-03-07'),
('jagan', 'Tony', 'Stark', 19, 'Female', 'BSc', '214748364756', 'Shivaji Nagar', 'Miraj', 'tony@rediffmail.com', '2020-03-07'),
('Chanda', 'Chandrakant', 'Patil', 23, 'Male', 'MBA', '987667886677', 'Near Durga', 'Miraj', 'chanda@gmail.com', '2020-03-09'),
('Pranit', 'Pranit', 'Kamble', 22, 'Male', 'MSc', '987564725365', 'Near Ganpati Talav', 'Miraj', '8745874596', '2020-03-09');

-- --------------------------------------------------------

--
-- Structure for view `v_skills`
--
DROP TABLE IF EXISTS `v_skills`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_skills` AS select `sm`.`service_type` AS `service_type`,`sp`.`w_uname` AS `w_uname` from (`service_provider` `sp` join `service_master` `sm` on((`sp`.`sid` = `sm`.`sid`)));
