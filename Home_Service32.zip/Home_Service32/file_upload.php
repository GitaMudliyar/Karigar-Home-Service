<html>
<body>
<center>
<?php
include "header.php";
$w_uname = $_GET["w_uname"];

echo "<p><img src='profile_pics/pic$w_uname.png' / height='200px' width='200px'></p>";
?>

<p><a href='worker_profile.php'>Back To List</a></p>

<form action="act_fileupload.php" method="post" enctype="multipart/form-data">
<input type="hidden" name="w_uname" value="<?php echo $w_uname; ?>" />
Select Picture File [.jpg or .png]:
<p>
<input type="file" name="file" />
</p>
<input type="submit"  value="Upload"/>
</center>
</form>
</body>
</html>