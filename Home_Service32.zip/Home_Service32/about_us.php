<?php
include "header.php";
?>

<html>
<body>
<center>
<div><h2 style='color:navy'><p>About Us</p></h2></div>
</center>

<center>
		<p class="thumbnail">
		<center>
		<img src="./img/g2.gif" height="300px" width="300px">
		</center>
		</p>
</center>
<br>


<center>
<div><p style='color:darkSlategray'>
Karigar Home Service is our commitment to bring professionalism, good service and trust to the home 
repair service and maintenance business. We take immense pride in sending some
 of the most professional handymen to your homes to fix things that aren't working.We provide 
 a platform to search for employment for skilled employees involving the rural region. </p>
 </div>
 
 
 
 
 <div class="container">
  <div class="row">
	<div class="col-xs-6"><p style='color:darkSlategray'>
				<h3>Our Vision</h3>
				To provide customers with home repair service experience that delights 
				them and become their best-handy-friend.
				<p>
				We also provide Employement Opportunities 
				
				</p>
	</div>

	
	<div class="col-xs-6">
		
			<div class="caption">
			<p style='color:darkSlategray'>
				<h3>Our Values</h3>
				We believe in our processes and in our people who lead them. 
				We enjoy the power of empowerment and delegation.
				</p>
			</div>
		</a>
	</div>
  </div>

</div>

 
 
 
 
 
 
</center>
</center>
</body>
</html>
<?php
include "footer.php";
?>