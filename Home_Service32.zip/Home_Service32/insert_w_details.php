<?php
include "header.php";
require "dbi.php";

$sid=$_POST["sid"];
//$service_type=$_POST["service_type"];
$w_uname=$_POST["w_uname"];

$query="insert into service_provider(sid,w_uname) values($sid,'$w_uname')";

mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	echo "<div class='well text-center'><h2 style='color:navy'><p><a href='worker.php'>Back</a></p></div>";
	echo "<div class='well text-center'><h2 style='color:green'>Success: Details Updated!</h2>";
	echo "<div class='well text-center'><h3 style='color:maroon'>To Add More Service(s)</h3>";
	echo "<p><a href='worker_work_details.php'>Click Here</a></p></div>";

}

?>
<!--	header("location:worker_work_details.php");-->