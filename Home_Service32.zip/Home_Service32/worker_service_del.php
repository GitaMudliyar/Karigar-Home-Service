<?php
include "header.php";
$service_type= $_GET["service_type"];

require "dbi.php";
$query="select * from v_skills";// where w_uname=$w_uname";

$result=mysqli_query($con,$query) or die(mysqli_error($con));


if($row=mysqli_fetch_array($result))
{
	$service_type=$row["service_type"];
}

?>
<html>
<body>
<center>
<p><a href='worker_work_details.php'>Back to List</a></p>

<form action="worker_service_delete.php" method="post">

<?php
$w_uname=$_GET["w_uname"];
$service_type=$_GET["service_type"];
	echo "<h2 style='color:red'>Delete Service: $service_type</h2>";
	echo "<h2>Are You Sure?</h2>";

?>

<input type="hidden" name="service_type" value="<?php echo $service_type; ?>"/>
<input type="hidden" name="w_uname" value="<?php echo $w_uname; ?>"/>


<input type="submit"  value="Confirm Delete"/>

</form>
</center>
</body>
</html>