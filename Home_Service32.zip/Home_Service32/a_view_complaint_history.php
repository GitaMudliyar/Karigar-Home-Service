<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>

<?php

include "header.php";
include "dbi.php";

$query = "select * from complaint where status='COMPLETED' order by cid";// where w_uname='$uname'";

$result=mysqli_query($con,$query);
echo "<p><center><a href='admin.php'> Back </a></center></p>";
echo "<h2 class='text-center'>Complaint History</h2>";
echo '<div class="table-responsive">';
echo '<table border>';
echo "<tr bgcolor='DeepPink'><th><center>Sr. No. </center></th><th><center>Date</center></th>";
echo "<th><center>From</center></th><th><center>To</center></th><th><center>Service</center></th>";
echo "<th><center>Details</th>";
echo "<th><center>Status</center></th></tr>";
$cnt=0;
while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$cid=$row["cid"];
	
	
	echo "<tr>";
	echo "<td>".$cnt."</td>";
	echo "<td>".$row["cdate"]."</td>";
	echo "<td>".$row["m_uname"]."</td>";
	echo "<td>".$row["w_uname"]."</td>";
	echo "<td>".$row["service_type"]."</td>";

	echo "<td>".$row["details"]."</td>";
	echo "<td>&nbsp;".$row["status"]."</td>";
	//echo "<td><a href='complaint_edit.php?cid=$cid'>Edit</a></td>";
	
	echo "</tr>";
	
}


echo "</table></div>";

mysqli_close($con);