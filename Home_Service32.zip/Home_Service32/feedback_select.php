<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>


<?php
//$fid=$_POST["fid"];
//$name=$_POST["name"];
//$e_mail=$_POST["e_mail"];
//$u_date=date("Y-m-d");
//$comments=$_POST["comments"];

include "dbi.php";
include "header.php";


$query="select * from feedback";

$result = mysqli_query($con,$query) or die(mysqli_error($con));
echo "<center>";

echo "<p><a href='admin.php'>Back</a></p>";

//$total = mysqli_num_rows($result);

//echo "<h3>".strtoupper($cn).": $total Product(s)</h3>";

echo "<table border='1'>";
echo "<tr bgcolor='gold'><th><center>Sr.No.</center></th><th><center>Name</center></th><th><center>E-mail</center></th>";
echo "<th><center>Received On</center></th><th><center>Comments</th><th><center>Delete</center></th></tr>";

$cnt=0;

while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$fid=$row["fid"];
	$name=$row["name"];

	echo "<tr>";
	echo "<td align='center'>$cnt</td>";
	echo "<td>&nbsp;".$row["name"]."</td>";
	echo "<td>&nbsp;".$row["e_mail"]."</td>";
	echo "<td>&nbsp;".$row["u_date"]."</td>";
	echo "<td>&nbsp;".$row["comments"]."</td>";
	echo "<td>";
	echo "&nbsp";
	//echo "<a href='feedback_del.php?fid=$fid'>Delete</a></td>";
	echo "<a href='feedback_del.php?fid=$fid&name=$name'>Delete</a></td>";
	echo "</tr>";
}

echo "</table><center>";

mysqli_close($con);
?>