<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>

<?php

include "header.php";
include "dbi.php";

$query = "select * from complaint where (status='COMPLETED' and m_nm='$uname') order by cid";// where w_uname='$uname'";

$result=mysqli_query($con,$query);
echo "<p><center><a href='member.php'> Back </a></center></p>";
echo "<h2 class='text-center'>Complaint History</h2>";
echo '<div class="table-responsive">';
echo '<table border>';
echo "<tr bgcolor='ChartReuse'><th><center>Sr. No. </center></th><th><center>Date</center></th>";
echo "<th><center>To</center></th>";
echo "<th><center>Service</center></th><th><center>Details</th>";
echo "<th><center>Status</center></th><th><center>Send Message</center></th></tr>";
$cnt=0;
while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$cid=$row["cid"];
	$nm=$row["w_uname"];
	
	
	echo "<tr>";
	echo "<td>".$cnt."</td>";
	echo "<td>".$row["cdate"]."</td>";
	echo "<td>".$row["w_uname"]."</td>";
	echo "<td>".$row["service_type"]."</td>";

	echo "<td>".$row["details"]."</td>";
	echo "<td>&nbsp;".$row["status"]."</td>";
	//echo "<td><a href='complaint_edit.php?cid=$cid'>Edit</a></td>";
	echo "<td><a href='member_send_message_to_worker.php?nm=$nm'>Send Message</a></td>";
	
	echo "</tr>";
	
}


echo "</table></div>";

mysqli_close($con);