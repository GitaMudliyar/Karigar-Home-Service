<?php
include "header.php";
?>
<style>
body{
	margin: 0;
	padding: 0;
	background : url(pic1.jpg); 
	background-size: cover;
	background-position: center;
	font-family: sans-serif;
}
</style>

<div class="panel panel-primary" style="max-width:300px;margin:auto">
		<div class="panel-heading">
			NEW MEMBER REGISTRATION
		</div>

		<div class="panel-body panel-center">
	<form class="form" action="register.php" method="post">		

<center>
<div class="form-group">
<label for="nameField">Select role</label><br><br><br>
<input type="radio" name="role" value="member" checked/>Member<br><br>
<input type="radio" name="role" value="worker"/>Worker
</div>

</center>

<input type="submit" class="btn btn-success btn-block" value="Register Now" /> 
</form>

		</div>

		<div class="panel-footer text-center">
		
<a href="login.php">Cancel</a>
		</div>

	</div>


<?php
include "footer.php";
?>




