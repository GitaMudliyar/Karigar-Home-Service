<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>
<?php
include "header.php";
require "dbi.php";

$query="select * from message where to_u='$uname' order by mid desc";

$result = mysqli_query($con,$query) or die(mysqli_error($con));

echo "<center>";

echo "<p><h3>Received Messages</h3></p>";

echo '<div class="table-responsive">';
echo "<table border='1'>";
echo "<tr bgcolor='gold'><th><center>Sr. No.</center></th><th><center>From</center></th><th><center>Date</center></th>";
echo "<th><center>Subject</center></th><th><center>Contents</center></th></tr>";

$cnt=0;

while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$from=$row["from_u"];
	$mdate=$row["mdate"];
	$subject=$row["subject"];
	$contents=$row["contents"];

	echo "<tr>";
	echo "<td align='center'>$cnt</td>";
	echo "<td>&nbsp;".$row["from_u"]."</td>";
	echo "<td>&nbsp;".$row["mdate"];
	
	echo "<td>&nbsp;".$row["subject"];
	echo "<td>&nbsp;".$row["contents"]."</td>";
	
	echo "<td>";
	//echo "&nbsp;<a href='edit_service.php? w_uname=$w_uname'>Send Message</a>";
	
	echo "</tr>";
}

echo "</table></div>";

echo "<br><p><a href='admin.php'>Back to Panel</a></p>";

echo "<center>";

mysqli_close($con);
?>