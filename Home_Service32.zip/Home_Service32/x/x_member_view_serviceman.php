<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}



tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>

<?php
$sid = $_GET["sid"];
$service_type = $_GET["service_type"];

include "header.php";
include "dbi.php";

$query="select * from service_provider where sid=$sid";

$result = mysqli_query($con,$query) or die(mysqli_error($con));
echo "<center>";

echo "<p><a href='member_service_list.php'>Back To Service List</a></p>";

$total = mysqli_num_rows($result);

echo "<h3>".strtoupper($service_type).": $total Worker(s)</h3>";

echo "<div class='table-responsive'><table>";
echo "<tr bgcolor='chartreuse'><th><center>Sr.No.</center></th><th><center>Serviceman</center></th><th><center>Action</center></th></tr>";

$cnt=0;

while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$id=$row["sid"];

	echo "<tr>";
	echo "<td align='center'>$cnt</td>";
	echo "<td>&nbsp;".$row["w_uname"]."</td>";
	echo "<td>";
	echo "&nbsp;<a href='view_worker_details.php'>More Details</a>";
	echo "</td>";
	echo "</tr>";
}

echo "</table></div><center>";

mysqli_close($con);
?>