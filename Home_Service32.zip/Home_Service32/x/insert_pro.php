<?php
require "dbi.php";

$cid=$_POST["cid"];
$pname=$_POST["pname"];
$rate=$_POST["rate"];

$query="insert into products(cid,pname,rate) values($cid,'$pname',$rate)";

mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	header("location:pro_list.php");
}

?>