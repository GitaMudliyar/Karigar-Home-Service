<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>
<?php
include "header.php";
require "dbi.php";

$query="select * from message where from_u='$uname'   order by mid desc";

$result = mysqli_query($con,$query) or die(mysqli_error($con));

echo "<center>";

echo "<p><h3>Sent Messages</h3></p>";

echo '<div class="table-responsive">';
echo "<table border='1'>";
echo "<tr bgcolor='ChartReuse'><th><center>Sr. No.</center></th><th><center>To</center></th><th><center>Date</center></th>";
echo "<th><center>Subject</center></th><th><center>Contents</center></th></tr>";

$cnt=0;

while($row=mysqli_fetch_array($result))
{
	$cnt++;
	

	echo "<tr>";
	echo "<td align='center'>$cnt</td>";
	echo "<td>&nbsp;".$row["to_u"]."</td>";
	echo "<td>&nbsp;".$row["mdate"]."</td>";
	
	echo "<td>&nbsp;".$row["subject"]."</td>";
	echo "<td>&nbsp;".$row["contents"]."</td>";
	
	echo "<td>";
		
	echo "</tr>";
}

echo "</table></div>";
echo "<br><p><a href='worker.php'>Back to Panel</a></p>";

echo "<center>";

mysqli_close($con);
?>