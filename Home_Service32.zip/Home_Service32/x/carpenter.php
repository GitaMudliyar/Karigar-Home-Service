<?php
include "header.php";   // require "header.php";
include "dbi.php";

$query = "select * from v_skills where service_type='carpenter'";

$result=mysqli_query($con,$query);


while($row=mysqli_fetch_array($result))
{
	
}

 ?>


 
 <?php
include "footer.php";   // require "header.php";
 ?>