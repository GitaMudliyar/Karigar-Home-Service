
<?php
include "header.php";
require "dbi.php";

$query="select * from service_provider";

$result = mysqli_query($con,$query) or die(mysqli_error($con));

echo "<center>";

//echo "<p><a href='new_service.php'>New Service</a></p>";

echo "<p><a href='member.php'>Back</a></p>";
echo '<div class="table-responsive">';
echo '<table border>';
echo "<tr bgcolor='ChartReuse'><th><center>Sr. No.</center></th><th><center>Name</center></th><th><center>Address</center></th>";

$cnt=0;

while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$id=$row["w_uname"];
	$service_type=$row["service_type"];

	echo "<tr>";
	echo "<td align='center'>$cnt</td>";
	echo "<td>&nbsp;".$row["service_type"]."</td>";

	echo "<td>";
	echo "&nbsp;<a href='member_view_serviceman.php?sid=$id&service_type=$service_type'>View Workers</a>";
	echo "</td>";

	echo "</tr>";
}

echo "</table></div>";

//echo "<p><a href='workers_list.php'>Worker(s) List</a></p>";

echo "<center>";

mysqli_close($con);
?>