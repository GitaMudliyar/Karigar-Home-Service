<?php
include "header.php";   // session started in header file - session_start();
include "dbi.php";

$fn=$_POST["fullname"];
$ci=$_POST["contactinfo"];
$udt=date("Y-m-d");

mysqli_query($con,"update admin_profile set fullname='$fn',contactinfo='$ci',udate='$udt' where a_uname='$uname'");
if(mysqli_affected_rows($con) > 0)
{
	echo "<div class='well text-center'><h2 style='color:green'>Success: Profile Updated!</h2>";
	echo "<p><a href='admin.php'>Back To Panel</a></p></div>";
}


include "footer.php";
?>