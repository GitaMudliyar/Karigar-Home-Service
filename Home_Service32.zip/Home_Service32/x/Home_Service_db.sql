-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 10, 2020 at 03:02 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `Home_Service_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `grevience`
--

CREATE TABLE IF NOT EXISTS `grevience` (
  `gid` int(11) NOT NULL,
  `gdate` int(11) NOT NULL,
  `m_uname` int(11) NOT NULL,
  `s_uname` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `details` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `workdone_date` int(11) NOT NULL,
  `estimated_date` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grevience`
--


-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `uname` varchar(25) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  `role` varchar(25) NOT NULL,
  `created_at` date NOT NULL,
  `see_ans` varchar(50) NOT NULL,
  `security_question` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--


-- --------------------------------------------------------

--
-- Table structure for table `member_profile`
--

CREATE TABLE IF NOT EXISTS `member_profile` (
  `m_uname` varchar(25) NOT NULL,
  `fname` varchar(25) NOT NULL,
  `lname` varchar(25) NOT NULL,
  `area` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  UNIQUE KEY `contact` (`contact`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member_profile`
--


-- --------------------------------------------------------

--
-- Table structure for table `servicer_profile`
--

CREATE TABLE IF NOT EXISTS `servicer_profile` (
  `s_uname` varchar(25) NOT NULL,
  `fname` varchar(25) NOT NULL,
  `lname` varchar(25) NOT NULL,
  `age` int(3) NOT NULL,
  `gender` varchar(8) NOT NULL,
  `qualification` varchar(20) NOT NULL,
  `area` varchar(25) NOT NULL,
  `location` varchar(25) NOT NULL,
  `contact` varchar(50) NOT NULL,
  PRIMARY KEY (`s_uname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `servicer_profile`
--


-- --------------------------------------------------------

--
-- Table structure for table `service_manager`
--

CREATE TABLE IF NOT EXISTS `service_manager` (
  `sid` int(5) NOT NULL,
  `service_type` varchar(30) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service_manager`
--


-- --------------------------------------------------------

--
-- Table structure for table `service_provider`
--

CREATE TABLE IF NOT EXISTS `service_provider` (
  `spid` int(5) NOT NULL,
  `sid` int(5) NOT NULL,
  `s_uname` varchar(50) NOT NULL,
  PRIMARY KEY (`spid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service_provider`
--

