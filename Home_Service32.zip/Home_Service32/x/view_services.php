<?php
include "header.php";
include "validate_worker.php";
include "dbi.php";
?>

<html>
<body>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>

<?php
//include "dbi.php";
//$w_uname=$_POST["w_uname"];
	$query="select * from v_skills";

$result = mysqli_query($con,$query) or die(mysqli_error($con));
echo "<center>";

echo "<p><a href='worker_work_details.php'>Back</a></p>";

echo "<table border='1'>";
echo "<tr bgcolor='darkCyan'><th><center>Sr.No.</center></th><th><center>Your Services</center></th>";
echo "<th><center>Delete</center></th></tr>";

$cnt=0;

while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$w_uname=$row["w_uname"];
	$service_type=$row["service_type"];

	echo "<tr>";
	echo "<td align='center'>$cnt</td>";
	echo "<td>&nbsp;".$row["service_type"]."</td>";

	echo "<td>";
	echo "&nbsp;<a href='worker_service_del.php?service_type=$service_type'>Delete</a>";
		//echo "&nbsp;<a href='del_pro.php?pid=$id'>Delete</a>";
	echo "</td>";


	echo "</tr>";
}

echo "</table>";
//echo "<p><a href='cat_list.php'>Category List</a></p>";
echo "</center>";

mysqli_close($con);
?>