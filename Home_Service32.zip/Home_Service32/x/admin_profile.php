<?php
include "header.php";

require "validate_admin.php";
?>
<style>
body{
	margin: 0;
	padding: 0;
	background : url(pic1.jpg); 
	background-size: cover;
	background-position: center;
	font-family: sans-serif;
}
</style>

<div class="panel panel-primary" style="max-width:300px;margin:auto">
		<div class="panel-heading">
			Admin Profile
		</div>

		<div class="panel-body panel-center">
	<form class="form" action="#">		


<div class="form-group">
<label for="nameField">User Name</label>
<input type="text" class="form-control input-sm" name="m_uname" required placeholder="User Name" />
</div>

<div class="form-group">
<label for="nameField">First Name</label>
<input type="text" class="form-control input-sm" name="fname" required placeholder="First Name" />
</div>

<div class="form-group">
<label for="nameField">Last Name</label>
<input type="text" class="form-control input-sm" name="lname" required placeholder="Last Name" />
</div>

<div class="form-group">
<label for="nameField">Area</label>
<input type="text" class="form-control input-sm" name="area" required placeholder="Address" />
</div>

<div class="form-group">
<label for="nameField">City</label>
<input type="text" class="form-control input-sm" name="location" required placeholder="Location Name" />
</div>



<div class="form-group">
<label for="nameField">Contact Info</label>
<input type="text" class="form-control input-sm" name="contact" required placeholder="Contact Details" />
</div>

<div class="form-group">
<label for="nameField">Updated on</label>
<input type="text" readonly class="form-control input-sm" name="udate" required placeholder="Updated Date" />
</div>


<input type="submit" class="btn btn-warning btn-block" value="Update Profile" /> 
</form>
		</div>

		<div class="panel-footer text-center">
			
<a href="admin.php">Back To Panel</a>
		</div>

	</div>


<?php
include "footer.php";
?>




