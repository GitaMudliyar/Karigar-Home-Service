<?php
include "header_main.php";   // require "header.php";
 ?>
   <div class="row">
	
	<div class="col-xs-3">
		<a href="#" class="thumbnail">
		<img src="./images/carpenter.png"></a>
			<div class="caption">
				<a href="edit"><h3>Edit</h3></a><a href="delete"><h3>Delete</h3></a>
				<a href="view"><h3>View</h3></a>
			</div>
	</div>
	
	
	
	
	
	
	<div class="col-xs-3">
		<a href="#" class="thumbnail">
		<img src="./images/electrician.png">
		</a>
	</div>
	<div class="col-xs-3">
		<a href="#" class="thumbnail">
		<img src="./images/painter.png">
		</a>
	</div>
	<div class="col-xs-3">
		<a href="#" class="thumbnail">
		<img src="./images/interior.png">
		</a>
	</div>
  </div>

  <div class="row">
	<div class="col-xs-3">
		<a href="#" class="thumbnail">
		<img src="./images/pool_cleaner.png">
		</a>
	</div>
	<div class="col-xs-3">
		<a href="#" class="thumbnail">
		<img src="./images/plumber.png">
		</a>
	</div>
	<div class="col-xs-3">
		<a href="#" class="thumbnail">
		<img src="./images/tree_shaper.png">
		</a>
	</div>
	<div class="col-xs-3">
		<a href="#" class="thumbnail">
		<img src="./images/tiles_fixer.png">
		</a>
	</div>
  </div>
  <?php
include "footer.php";   // require "header.php";
 ?>