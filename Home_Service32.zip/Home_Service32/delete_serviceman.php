<?php
$w_uname= $_POST["w_uname"];
require "dbi.php";

$query="delete from worker_profile where w_uname='$w_uname'";

mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	header("location:service_list.php");
}

?>