<?php
require "dbi.php";

$query="select * from category order by cid";

$result = mysqli_query($con,$query) or die(mysqli_error($con));

echo "<center>";

echo "<p><a href='new_cat.php'>New Category</a></p>";

echo "<table border='1'>";
echo "<tr bgcolor='gold'><th>No</th><th>Category</th><th>Action</th></tr>";

$cnt=0;

while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$id=$row["cid"];
	$cn=$row["cname"];

	echo "<tr>";
	echo "<td align='center'>$cnt</td>";
	echo "<td>&nbsp;".$row["cname"]."</td>";

	
	echo "<td>";
	echo "&nbsp;<a href='edit_cat.php?cid=$id'>Edit</a>";
	echo "&nbsp;<a href='del_cat.php?cid=$id'>Delete</a>";
	echo "&nbsp;<a href='view_cat_products.php?cid=$id&cn=$cn'>Products</a>";
	echo "</td>";

	echo "</tr>";
}

echo "</table>";

echo "<p><a href='pro_list.php'>Product List</a></p>";

echo "<center>";

mysqli_close($con);
?>