<?php
include "header.php";
$sid= $_GET["sid"];

require "dbi.php";
$query="select * from service_provider where sid=$sid";

$result=mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_num_rows($result) > 0)
{
	echo "<center><h2 style='color:red'>Products Exist. Cannot Delete Category</h2>";
	echo "<p><a href='service_list.php'>Back to List</a></p></center>";
	exit;
}

$query="select * from service_master where sid=$sid";

$result=mysqli_query($con,$query) or die(mysqli_error($con));

if($row=mysqli_fetch_array($result))
{
	$service_type=$row["service_type"];
}
else
{
	
	echo "<center><h2>Service Not Found</h2>";
	echo "<p><a href='service_list.php'>Back to List</a></p></center>";
	exit;
}

?>
<html>
<body>
<center>
<p><a href='service_list.php'>Back to List</a></p>

<form action="delete_service.php" method="post">

<?php
	echo "<h2 style='color:red'>Delete Service: $service_type @ SID: $sid</h2>";
	echo "<h2>Are You Sure?</h2>";

?>

<input type="hidden" name="sid" value="<?php echo $sid; ?>" />


<input type="submit"  value="Confirm Delete"/>

</form>
</center>
</body>
</html>