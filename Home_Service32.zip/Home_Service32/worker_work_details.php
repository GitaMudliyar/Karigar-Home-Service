<?php
include "header.php";
include "validate_worker.php";
include "dbi.php";
?>
<html>
<body>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}
th{
	color:white;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>
<center>
<p><a href='worker.php'>Back</a></p>


<form action="insert_w_details.php" method="post">
<div class="table-responsive">
<?php


if(!empty($uname))
{
	$result = mysqli_query($con,"select * from worker_profile where w_uname='$uname'");

	if($row=mysqli_fetch_array($result))
	{
		
$w_uname=$row["w_uname"];
	}
}
?>
<table border>
<tr bgcolor='darkCyan'><td colspan="2" align='center'>
<font color="white"><b>WORK DETAILS</b></font>
</td></tr>

<tr>
<td>Name:-</td>
<td><input type="text" readonly name="w_uname" value="<?php echo $uname;?>"/></td>
</tr>





<tr>
<td>SELECT SERVICE:-</td>
<td>
<select name="sid">
<?php
//include "dbi.php";

$query="select * from service_master";

$result = mysqli_query($con,$query);

while($row=mysqli_fetch_array($result))
{
	$sid=$row["sid"];
	$service_type=$row["service_type"];

	echo "<option value='$sid'>$service_type</option>";
}


?>
</select>

</td>
</tr>


<tr bgcolor='Honeydew'><td colspan="2" align='center'>
<input type="submit"  value="ADD"/>
</td>
</tr>
</table>


<!--View services table added below-->

<?php
//include "dbi.php";
//$w_uname=$_POST["w_uname"];
	$query="select * from v_skills where w_uname='$uname'";

$result = mysqli_query($con,$query) or die(mysqli_error($con));
echo "<center>";

//echo "<p><a href='worker_work_details.php'>Back</a></p>";
echo "<br>";echo "<br>";echo "<br>";echo "<br>";

echo "<table border='1'>";
echo "<tr bgcolor='darkCyan'><th><center>Sr.No.</center></th><th><center>Your Services</center></th>";
echo "<th><center>Delete</center></th></tr>";

$cnt=0;

while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$w_uname=$row["w_uname"];
	$service_type=$row["service_type"];

	echo "<tr>";
	echo "<td align='center'>$cnt</td>";
	echo "<td>&nbsp;".$row["service_type"]."</td>";

	echo "<td>";
	echo "&nbsp;<a href='worker_service_del.php?service_type=$service_type&w_uname=$w_uname'>Delete</a>";
		//echo "&nbsp;<a href='del_pro.php?pid=$id'>Delete</a>";
	echo "</td>";


	echo "</tr>";
}

echo "</table>";
//echo "<p><a href='cat_list.php'>Category List</a></p>";
echo "</center>";

mysqli_close($con);
?>








</div>
</form>
</center>
</body>
</html>