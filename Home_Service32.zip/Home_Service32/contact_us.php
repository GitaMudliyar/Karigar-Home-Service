<?php
include "header.php";
?>

<html>
<style>
table{
	 background-color:black;
}
</style>
<body>
<center>
<div><h2 style='color:navy'><p> Contact Us</p></h2></div>
</center>
<marquee BEHAVIOR=alternate>
<table>
<tr>
<td><img src="img/1.jpg" class="thumbnail" width="180px" height="140px"/></td>
<td><img src="img/18.jpg" class="thumbnail" width="180px" height="140px"/></td>
<td><img src="img/5.jpg" class="thumbnail" width="180px" height="140px"/></td>
<td><img src="img/6.jpg" class="thumbnail" width="180px" height="140px"/></td>
<td><img src="img/16.jpg" class="thumbnail" width="180px" height="140px"/></td>
<td><img src="img/11.jpg" class="thumbnail" width="180px" height="140px"/></td>
<td><img src="img/3.jpg" class="thumbnail" width="180px" height="140px"/></td>
<td><img src="img/2.jpg" class="thumbnail" width="180px" height="140px"/></td>
<td><img src="img/7.jpg" class="thumbnail" width="180px" height="140px"/></td>
<td><img src="img/4.jpg" class="thumbnail" width="180px" height="140px"/></td>
</tr>

</table>
</marquee>
<center>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d122189.8734698753!2d74.51405940668576!3d16.85443471524121!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc10c8187f060eb%3A0x37911f53cdc1ddb3!2sSangli%2C+Maharashtra!5e0!3m2!1sen!2sin!4v1491388946089" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>

<br>
<div><h3 style='color:navy'><p>Karigar Home Service</p></h3>
<center>
<h4 style='color:MediumVioletRed'> Near Karmaveer Bhaurao Patil Vidyalaya,<br> 
Janwade Malla ,Samtanagar,Miraj <br></h4>
 <h4 style='color:MediumVioletRed'>E-mail:- gitamudliyar2@gmail.com, nikitakadapure@gmail.com<br>
 Phone:- 9021094915, 9725228687<h4>
 
 </div>
 <br><br><br><br>
</center>
</center>
</body>
</html>
<?php
include "footer.php";
?>