<?php
include "header.php";
require "dbi.php";


$fid=$_POST["fid"];
$name=$_POST["name"];
$e_mail=$_POST["e_mail"];
$u_date=date("Y-m-d");
$comments=$_POST["comments"];



$query="insert into feedback(fid,name,e_mail,u_date,comments) values('$fid','$name','$e_mail','$u_date','$comments' )";

mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	header("location:feedback_success.php");
}

?>